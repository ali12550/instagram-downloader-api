# Instagram Downloader API

A simple Node.js API to fetch Instagram public media (video, photo, reels).

## Usage

Endpoint: `/download?url=<instagram-post-code>&key=<your-api-key>`

Example:

